//
//  SCContextAwareSnapCreationThrottleRequest.h
//  SCCamera
//
//  Created by Cheng Jiang on 4/24/18.
//

#import <SCFoundation/SCContextAwareThrottleRequester.h>

#import <Foundation/Foundation.h>

@interface SCContextAwareSnapCreationThrottleRequest : NSObject <SCContextAwareThrottleRequest>

- (instancetype)init;

@end
