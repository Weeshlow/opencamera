//
//  SCManagedCaptureDeviceLinearInterpolationZoomHandler.h
//  Snapchat
//
//  Created by Joe Qiao on 03/01/2018.
//

#import "SCManagedCaptureDeviceDefaultZoomHandler.h"

@interface SCManagedCaptureDeviceLinearInterpolationZoomHandler : SCManagedCaptureDeviceDefaultZoomHandler

@end
