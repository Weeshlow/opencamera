//
//  SCScanConfiguration.m
//  Snapchat
//
//  Created by Yang Dai on 3/7/17.
//  Copyright © 2017 Snapchat, Inc. All rights reserved.
//

#import "SCScanConfiguration.h"

@implementation SCScanConfiguration

@end
