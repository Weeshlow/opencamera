//
//  UIScreen+Debug.h
//  Snapchat
//
//  Created by Derek Peirce on 6/1/17.
//  Copyright © 2017 Snapchat, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScreen (Debug)

@end
